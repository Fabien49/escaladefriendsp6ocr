package com.fabienIT.escaladefriendsp6ocr.service;

import java.util.Collection;

import com.fabienIT.escaladefriendsp6ocr.model.Employee;


public interface EmployeeServiceInterface {

	public Employee saveEmployee(Employee emp);
	public Boolean deleteEmployee(String empId);
	public Employee editEmployee(Employee emp);
	public Employee findEmployee(String empId);
	public Collection<Employee> getAllEmployees();
}
